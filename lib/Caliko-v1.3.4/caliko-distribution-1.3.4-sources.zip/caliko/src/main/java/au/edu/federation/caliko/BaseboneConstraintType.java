package au.edu.federation.caliko;

/**
 * @author jsalvo
 */
public interface BaseboneConstraintType {

}
